Thiru. A. Govindasamy Government Arts College - Website

How to run:
1. Extract the ZIP.
2. Open index.html in any modern web browser.

The phone number, email, official course list, notices and other institutional details are placeholders and should be replaced with verified college information before publishing.
