const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

menuToggle.addEventListener("click", () => {
  navLinks.classList.toggle("open");
});

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => navLinks.classList.remove("open"));
});

document.getElementById("year").textContent = new Date().getFullYear();

const notices = [
  "Welcome to the official college website.",
  "Admission and examination updates can be published in this section.",
  "Students are encouraged to participate in academic and extracurricular activities."
];
let noticeIndex = 0;
setInterval(() => {
  noticeIndex = (noticeIndex + 1) % notices.length;
  document.getElementById("noticeText").textContent = notices[noticeIndex];
}, 4500);

document.getElementById("contactForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  document.getElementById("formMessage").textContent =
    `Thank you, ${name || "student"}! Your message has been prepared.`;
  this.reset();
});
